---
name: "[dashboard] Refresh Notebooks"
about: "Trigger the workflow for refreshing all notebooks."
title: "[dashboard] Refresh Notebooks"
labels: fastpages-automation
assignees: ''

---

Opening this issue will trigger GitHub Actions to refresh all notebooks.
